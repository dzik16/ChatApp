import {combineReducers} from 'redux';
import {UserReducer} from './user';

const reducer = combineReducers({
  UserReducer,
});

export default reducer;
