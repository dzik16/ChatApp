export const SET_LOADING = '@@@SET_LOADING';

export const SET_USER = '@@@SET_USER';

export const SET_LOGIN = '@@@SET_LOGIN';
export const LOGIN_LOADING = '@@@LOGIN_LOADING';

export const REGISTER_LOADING = '@@@REGISTER_LOADING';

export const LOGUT_USER = '@@@LOGUT_USER';
