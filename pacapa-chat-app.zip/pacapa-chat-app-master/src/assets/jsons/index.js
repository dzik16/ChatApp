import LogoSplash from './logo_splas.json';
import SplashAnim from './SplashAnim.json';
import LoginAnim from './LoginAnim.json';

export {LogoSplash, SplashAnim, LoginAnim};
