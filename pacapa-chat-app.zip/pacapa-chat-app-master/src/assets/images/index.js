import FotoDefault from './—Pngtree—avatar icon profile icon member_5247852.png';

import BackgroundChat from './BackgroundChat.jpg';
import EmptyChat from './Empty-Chat.png';
export {FotoDefault, BackgroundChat, EmptyChat};
