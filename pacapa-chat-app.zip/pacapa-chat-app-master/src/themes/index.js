import theme, {COLORS, SIZES, FONTS} from './theme';

export {theme, COLORS, SIZES, FONTS};
